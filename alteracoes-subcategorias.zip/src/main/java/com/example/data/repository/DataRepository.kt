package com.example.data.repository

import android.util.Log
import com.example.data.api.SpringApiService
import com.example.data.model.Cliente
import com.example.data.model.Maquina
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.concurrent.TimeUnit
import kotlin.random.Random

class DataRepository {

    private val _baseUrl = MutableStateFlow("https://maquinas72.azurewebsites.net/")
    val baseUrl: StateFlow<String> = _baseUrl.asStateFlow()

    private val _isDemoMode = MutableStateFlow(false)
    val isDemoMode: StateFlow<Boolean> = _isDemoMode.asStateFlow()

    private var apiService: SpringApiService? = null
    private val cookieJar = SimpleCookieJar()

    // Generous high-quality mock datasets for robust demo testing
    private val mockClientes = mutableListOf<Cliente>()
    private val mockMaquinas = mutableListOf<Maquina>()
    private val localSolicitacoes = mutableListOf<com.example.data.model.SolicitacaoResponseDTO>()

    init {
        if (_isDemoMode.value) {
            generateMockData()
        }
        rebuildRetrofit()
    }

    fun setDemoMode(demo: Boolean) {
        _isDemoMode.value = demo
        if (demo && mockClientes.isEmpty()) {
            generateMockData()
        } else if (!demo) {
            mockClientes.clear()
            mockMaquinas.clear()
        }
    }

    fun updateBaseUrl(newUrl: String) {
        var cleanUrl = newUrl.trim()
        if (!cleanUrl.endsWith("/")) {
            cleanUrl += "/"
        }
        if (cleanUrl.startsWith("http://") || cleanUrl.startsWith("https://")) {
            _baseUrl.value = cleanUrl
            rebuildRetrofit()
        }
    }

    private fun rebuildRetrofit() {
        try {
            val logging = HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BODY
            }
            val okHttpClient = OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(15, TimeUnit.SECONDS)
                .addInterceptor(logging)
                .cookieJar(cookieJar)
                .build()

            val moshi = Moshi.Builder()
                .addLast(KotlinJsonAdapterFactory())
                .build()

            val retrofit = Retrofit.Builder()
                .baseUrl(_baseUrl.value)
                .client(okHttpClient)
                .addConverterFactory(MoshiConverterFactory.create(moshi))
                .build()

            apiService = retrofit.create(SpringApiService::class.java)
        } catch (e: Exception) {
            Log.e("DataRepository", "Failed to build Retrofit: ${e.message}")
            apiService = null
        }
    }

    private fun generateMockData() {
        val bairros = listOf(
            "Centro", "Jardim Paulista", "Copacabana", "Vila Mariana", "Pinheiros",
            "Ipanema", "Barra da Tijuca", "Savassi", "Batel", "Moinhos de Vento",
            "Moema", "Botafogo", "Leblon", "Perdizes", "Santana", "Consolação"
        )

        val contatos = listOf(
            "Carlos Silva", "Ana Oliveira", "Marcos Souza", "Juliana Santos",
            "Roberto Costa", "Patricia Lima", "Felipe Almeida", "Beatriz Rocha",
            "Renato Carvalho", "Mariana Pereira"
        )

        val nomMaqPrefixes = listOf("Slot", "Vending Coffee", "Fliperama", "Fliperama Arcade", "Mesa Bilhar", "Dardo Eletrônico")
        val nomJogos = listOf("Double Diamond", "Nespresso Pro", "Pac-Man Retro", "Street Fighter II", "Classic Pool", "Darts Masters", "Golden Fruits", "Wild West Slot", "Pinball Space")

        // 1. Generate 80 clients
        for (i in 1..80) {
            val clientPhone = "(11) 9${Random.nextInt(8000, 9999)}-${Random.nextInt(1000, 9999)}"
            val clientBairro = bairros[Random.nextInt(bairros.size)]
            val clientContato = contatos[Random.nextInt(contatos.size)]
            val clientName = when (Random.nextInt(4)) {
                0 -> "Bar e Lanchonete ${bairros[Random.nextInt(bairros.size)]} - $i"
                1 -> "Supermercado Pão de Ouro Unit $i"
                2 -> "Hotel Imperial ($clientContato)"
                else -> "Shopping Entretenimento Ltda - $i"
            }
            
            // Random datetime in the last year
            val year = 2025
            val month = Random.nextInt(1, 13)
            val day = Random.nextInt(1, 28)
            val dateStr = String.format("%04d-%02d-%02dT10:30:00", year, month, day)

            val cliente = Cliente(
                codCliente = i.toLong(),
                nomCliente = clientName,
                logradouro = "Av. Principal, nº ${i * 15}",
                telefone = clientPhone,
                bairro = clientBairro,
                contato = clientContato,
                leiturista = Random.nextInt(1, 8),
                regiao = Random.nextInt(1, 7), // 1 to 6 mapped regions
                dtCadastro = dateStr,
                ativo = Random.nextDouble() > 0.15 // 85% active
            )
            mockClientes.add(cliente)
        }

        // 2. Generate 150 machines associated with random clients
        for (i in 1..150) {
            val clientOwnerId = Random.nextInt(1, 81)
            val machineAtive = Random.nextDouble() > 0.1 // 90% active
            val placa = "${listOf("SP", "RJ", "MG", "PR")[Random.nextInt(4)]}-${Random.nextInt(10000, 99999)}"
            val mName = nomMaqPrefixes[Random.nextInt(nomMaqPrefixes.size)] + " Model " + ('A' + Random.nextInt(26))
            val mJogo = nomJogos[Random.nextInt(nomJogos.size)]
            
            val maquina = Maquina(
                id = i.toLong(),
                nom_maq = mName,
                nom_jogo = mJogo,
                numeroPlaca = placa,
                obs = if (Random.nextBoolean()) "Manuntenção preventiva ok" else "Checkin realizado dia ${Random.nextInt(1, 30)}",
                codCliente = clientOwnerId,
                ativo = machineAtive
            )
            mockMaquinas.add(maquina)
        }

        // Link machines back to clients
        for (idx in mockClientes.indices) {
            val c = mockClientes[idx]
            val clientMachines = mockMaquinas.filter { it.codCliente == c.codCliente?.toInt() }
            mockClientes[idx] = c.copy(maquinas = clientMachines)
        }
    }

    // Paginated, filtered, searched Client retrievals
    // Regra de visibilidade por leiturista (mesma regra aplicada no backend):
    //  - null ou 0 -> sem filtro (admin vê todos os clientes)
    //  - 1         -> vê os clientes dos leituristas 1, 4 e 10 (grupo geral)
    //  - 4         -> vê SOMENTE os próprios clientes
    //  - demais    -> vê os próprios clientes + grupo 10 (regra padrão)
    private fun leituristaAllowedList(userLeiturista: Int?): List<Int>? {
        if (userLeiturista == null || userLeiturista == 0 || userLeiturista == 10) return null
        return when (userLeiturista) {
            1 -> listOf(1, 4)
            else -> listOf(userLeiturista)
        }
    }

    suspend fun getClientes(
        page: Int,
        size: Int,
        search: String?,
        regiao: Int?,
        ativo: Boolean?,
        bairro: String? = null,
        leiturista: Int? = null
    ): List<Cliente> {
        val allowedLeituristas = leituristaAllowedList(leiturista)

        if (_isDemoMode.value) {
            var filtered = mockClientes.asSequence().filter { !it.isExcluded() }
            
            if (!search.isNullOrBlank()) {
                filtered = filtered.filter {
                    it.nomCliente?.contains(search, ignoreCase = true) == true ||
                    it.logradouro?.contains(search, ignoreCase = true) == true ||
                    it.contato?.contains(search, ignoreCase = true) == true ||
                    it.bairro?.contains(search, ignoreCase = true) == true
                }
            }
            if (regiao != null) {
                filtered = filtered.filter { it.regiao == regiao }
            }
            if (ativo != null) {
                filtered = filtered.filter { it.ativo == ativo }
            }
            if (!bairro.isNullOrBlank()) {
                filtered = filtered.filter { it.bairro?.equals(bairro, ignoreCase = true) == true }
            }
            if (allowedLeituristas != null) {
                filtered = filtered.filter { allowedLeituristas.contains(it.leiturista) }
            }

            // Paginate
            val list = filtered.toList()
            val startIdx = page * size
            if (startIdx >= list.size) return emptyList()
            val endIdx = (startIdx + size).coerceAtMost(list.size)
            return list.subList(startIdx, endIdx)
        } else {
            // Live Retrofit mode with local sync and smart filtering
            return try {
                // Fetch the list from the Spring endpoint
                val rawApiList = try {
                    val resp = apiService?.getClientesPage(page, size, search, regiao, ativo)
                    resp?.content
                } catch (e: Exception) {
                    null
                } ?: apiService?.getClientes(page, size, search, regiao, ativo, bairro, leiturista) ?: emptyList()

                // Fetch machine details for each client since Spring API might not populate the relationship out of the box
                val apiList = rawApiList.map { apiCli ->
                    val cod = apiCli.codCliente
                    val clientMachines = if (cod != null) {
                        try {
                            apiService?.getMaquinasPorCliente(cod.toInt()) ?: emptyList()
                        } catch (e: Exception) {
                            Log.e("DataRepository", "Error fetching machines for client $cod: ${e.message}")
                            apiCli.maquinas ?: emptyList()
                        }
                    } else {
                        apiCli.maquinas ?: emptyList()
                    }
                    apiCli.copy(maquinas = clientMachines)
                }

                // sync memory cache with latest retrieved API data
                if (apiList.isNotEmpty()) {
                    if (page == 0) {
                        mockClientes.clear()
                        mockMaquinas.clear()
                    }
                    // Update main client list cache with live results (preserving other clients if this is a partial list)
                    apiList.forEach { apiCli ->
                        val existingIdx = mockClientes.indexOfFirst { it.codCliente == apiCli.codCliente }
                        if (existingIdx != -1) {
                            mockClientes[existingIdx] = apiCli
                        } else {
                            mockClientes.add(apiCli)
                        }

                        // Also extract its machines to synchronize locally
                        apiCli.maquinas?.forEach { maq ->
                            val existingMaqIdx = mockMaquinas.indexOfFirst { it.id == maq.id }
                            val maqWithCod = if (maq.codCliente == null && apiCli.codCliente != null) {
                                maq.copy(codCliente = apiCli.codCliente.toInt())
                            } else {
                                maq
                            }
                            if (existingMaqIdx != -1) {
                                mockMaquinas[existingMaqIdx] = maqWithCod
                            } else {
                                mockMaquinas.add(maqWithCod)
                            }
                        }
                    }
                }

                // Apply professional client-side filtering over the fetched API list 
                // in case the server-side controller doesn't process query params.
                var filtered = apiList.asSequence().filter { !it.isExcluded() }
                if (!search.isNullOrBlank()) {
                    filtered = filtered.filter {
                        it.nomCliente?.contains(search, ignoreCase = true) == true ||
                        it.logradouro?.contains(search, ignoreCase = true) == true ||
                        it.contato?.contains(search, ignoreCase = true) == true ||
                        it.bairro?.contains(search, ignoreCase = true) == true
                    }
                }
                if (regiao != null) {
                    filtered = filtered.filter { it.regiao == regiao }
                }
                if (ativo != null) {
                    filtered = filtered.filter { it.ativo == ativo }
                }
                if (!bairro.isNullOrBlank()) {
                    filtered = filtered.filter { it.bairro?.equals(bairro, ignoreCase = true) == true }
                }
                if (allowedLeituristas != null) {
                    filtered = filtered.filter { allowedLeituristas.contains(it.leiturista) }
                }

                val list = filtered.toList()
                val startIdx = page * size
                if (startIdx >= list.size) {
                    emptyList()
                } else {
                    val endIdx = (startIdx + size).coerceAtMost(list.size)
                    list.subList(startIdx, endIdx)
                }
            } catch (e: Exception) {
                Log.e("DataRepository", "Error getting live clients: ${e.message}. Falling back to cached data.")
                getClientesDemoFallback(page, size, search, regiao, ativo, bairro, leiturista)
            }
        }
    }

    private fun getClientesDemoFallback(
        page: Int,
        size: Int,
        search: String?,
        regiao: Int?,
        ativo: Boolean?,
        bairro: String?,
        leiturista: Int? = null
    ): List<Cliente> {
        val allowedLeituristas = leituristaAllowedList(leiturista)
        var filtered = mockClientes.asSequence().filter { !it.isExcluded() }
        if (!search.isNullOrBlank()) {
            filtered = filtered.filter {
                it.nomCliente?.contains(search, ignoreCase = true) == true ||
                it.bairro?.contains(search, ignoreCase = true) == true
            }
        }
        if (regiao != null) filtered = filtered.filter { it.regiao == regiao }
        if (ativo != null) filtered = filtered.filter { it.ativo == ativo }
        if (!bairro.isNullOrBlank()) filtered = filtered.filter { it.bairro == bairro }
        if (allowedLeituristas != null) filtered = filtered.filter { allowedLeituristas.contains(it.leiturista) }

        val list = filtered.toList()
        val startIdx = page * size
        if (startIdx >= list.size) return emptyList()
        val endIdx = (startIdx + size).coerceAtMost(list.size)
        return list.subList(startIdx, endIdx)
    }

    suspend fun getMaquinas(
        page: Int,
        size: Int,
        search: String?,
        ativo: Boolean?,
        codCliente: Int? = null,
        leiturista: Int? = null
    ): List<Maquina> {
        val allowedLeituristas = leituristaAllowedList(leiturista)

        if (_isDemoMode.value) {
            var filtered = mockMaquinas.asSequence().filter { !it.isExcluded() && !isClientExcluded(it.codCliente) }

            if (!search.isNullOrBlank()) {
                filtered = filtered.filter {
                    it.nom_maq?.contains(search, ignoreCase = true) == true ||
                    it.nom_jogo?.contains(search, ignoreCase = true) == true ||
                    it.numeroPlaca?.contains(search, ignoreCase = true) == true ||
                    it.obs?.contains(search, ignoreCase = true) == true
                }
            }
            if (ativo != null) {
                filtered = filtered.filter { it.ativo == ativo }
            }
            if (codCliente != null) {
                filtered = filtered.filter { it.codCliente == codCliente }
            }
            if (allowedLeituristas != null) {
                filtered = filtered.filter { m ->
                    val cli = mockClientes.find { it.codCliente?.toInt() == m.codCliente }
                    allowedLeituristas.contains(cli?.leiturista)
                }
            }

            val list = filtered.toList()
            val startIdx = page * size
            if (startIdx >= list.size) return emptyList()
            val endIdx = (startIdx + size).coerceAtMost(list.size)
            return list.subList(startIdx, endIdx)
        } else {
            // Live Retrofit mode: fetch live machines or populate them from live clients
            try {
                if (codCliente != null) {
                    val list = apiService?.getMaquinasPorCliente(codCliente) ?: emptyList()
                    list.forEach { m ->
                        val existingIdx = mockMaquinas.indexOfFirst { it.id == m.id }
                        val mWithCod = if (m.codCliente == null) m.copy(codCliente = codCliente) else m
                        if (existingIdx != -1) {
                            mockMaquinas[existingIdx] = mWithCod
                        } else {
                            mockMaquinas.add(mWithCod)
                        }
                    }
                } else {
                    // Try fetching all machines directly from api/maquinas if endpoint exists
                    try {
                        val directList = apiService?.getMaquinas(0, 1000, null, null, null) ?: emptyList()
                        if (directList.isNotEmpty()) {
                            // Update our local cache with direct API results
                            directList.forEach { m ->
                                val existingIdx = mockMaquinas.indexOfFirst { it.id == m.id }
                                if (existingIdx != -1) {
                                    mockMaquinas[existingIdx] = m
                                } else {
                                    mockMaquinas.add(m)
                                }
                            }
                        }
                    } catch (e: Exception) {
                        Log.e("DataRepository", "Direct api/maquinas failed: ${e.message}. Using client-by-client extraction fallback.")
                    }

                    // To be absolutely certain we have all machines and association with clients,
                    // we query all active clients and fetch their respective machines.
                    try {
                        val activeClients = apiService?.getClientes(0, 500, null, null, null, null, leiturista) ?: emptyList()
                        activeClients.forEach { cli ->
                            val cod = cli.codCliente
                            if (cod != null) {
                                try {
                                    val clMachines = apiService?.getMaquinasPorCliente(cod.toInt()) ?: emptyList()
                                    clMachines.forEach { m ->
                                        val existingIdx = mockMaquinas.indexOfFirst { it.id == m.id }
                                        val mWithCod = if (m.codCliente == null) m.copy(codCliente = cod.toInt()) else m
                                        if (existingIdx != -1) {
                                            mockMaquinas[existingIdx] = mWithCod
                                        } else {
                                            mockMaquinas.add(mWithCod)
                                        }
                                    }
                                } catch (e: Exception) {
                                    // Squelch individual client failures
                                }
                            }
                        }
                    } catch (e: Exception) {
                        Log.e("DataRepository", "Failed to fetch clients for machine list: ${e.message}")
                    }
                }
            } catch (e: Exception) {
                Log.e("DataRepository", "Critical error in getMaquinas live fetch: ${e.message}")
            }
            return getMaquinasDemoFallback(page, size, search, ativo, codCliente, leiturista)
        }
    }

    private fun getMaquinasDemoFallback(
        page: Int,
        size: Int,
        search: String?,
        ativo: Boolean?,
        codCliente: Int?,
        leiturista: Int? = null
    ): List<Maquina> {
        val allowedLeituristas = leituristaAllowedList(leiturista)
        var filtered = mockMaquinas.asSequence().filter { !it.isExcluded() && !isClientExcluded(it.codCliente) }
        if (!search.isNullOrBlank()) {
            filtered = filtered.filter {
                it.nom_maq?.contains(search, ignoreCase = true) == true ||
                it.numeroPlaca?.contains(search, ignoreCase = true) == true
            }
        }
        if (ativo != null) filtered = filtered.filter { it.ativo == ativo }
        if (codCliente != null) filtered = filtered.filter { it.codCliente == codCliente }
        if (allowedLeituristas != null) {
            filtered = filtered.filter { m ->
                val cli = mockClientes.find { it.codCliente?.toInt() == m.codCliente }
                allowedLeituristas.contains(cli?.leiturista)
            }
        }

        val list = filtered.toList()
        val startIdx = page * size
        if (startIdx >= list.size) return emptyList()
        val endIdx = (startIdx + size).coerceAtMost(list.size)
        return list.subList(startIdx, endIdx)
    }

    private fun isClientExcluded(codCliente: Int?): Boolean {
        if (codCliente == null) return false
        val client = mockClientes.find { it.codCliente == codCliente.toLong() }
        return client?.isExcluded() ?: false
    }

    // Helper to fetch matching client for a machine
    fun getClientForMachine(codCliente: Int?): Cliente? {
        if (codCliente == null) return null
        return mockClientes.find { it.codCliente == codCliente.toLong() }
    }

    // List of unique neighbourhoods for filter lists
    fun getUniqueBairros(): List<String> {
        return mockClientes.mapNotNull { it.bairro }.distinct().sorted()
    }

    suspend fun login(username: String, senha: String): com.example.data.model.Usuario? {
        if (_isDemoMode.value) {
            // Simulated database user password registry matching
            val lowerUser = username.lowercase().trim()
            val validSenha = when (lowerUser) {
                "marcio" -> "marcio123"
                "admin" -> "admin123"
                "tecnico" -> "tecnico123"
                "leiturista" -> "leiturista123"
                else -> null // DO NOT allow any other user to log in if not in simulated database
            }

            if (validSenha == null || senha != validSenha) {
                Log.w("DataRepository", "Demo Login failed: username / password mismatch or user not in database!")
                return null
            }

            val isLeiturista = username.lowercase().contains("leiturista")
            return com.example.data.model.Usuario(
                id = 1L,
                username = username,
                senha = validSenha,
                leiturista = if (isLeiturista) 1 else 0,
                idPontos = 10,
                ultimoAcesso = java.time.LocalDateTime.now().toString(),
                telefone = "11999998888",
                nome = username.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() },
                email = "$username@systempro.com.br",
                cargo = if (isLeiturista) "Leiturista" else "Técnico de Manutenção",
                equipe = "Equipe Alfa",
                unidade = "São Paulo - LWD"
            )
        }

        try {
            val apiResponse = apiService?.loginApi(com.example.data.model.UserLoginRequest(username, senha))
            if (apiResponse != null) {
                if (apiResponse.isSuccessful) {
                    return apiResponse.body()
                }
                // 401/403: credenciais inválidas confirmadas pelo backend.
                // Não cair em nenhum fallback que finja sucesso.
                Log.w("DataRepository", "loginApi rejected: HTTP ${apiResponse.code()}")
                return null
            }
        } catch (e: Exception) {
            Log.e("DataRepository", "loginApi failed: ${e.message}")
        }
        return null
    }

    suspend fun getSolicitacoesAbertasCount(): Int {
        if (_isDemoMode.value) {
            if (localSolicitacoes.isEmpty()) {
                generateMockSolicitacoes()
            }
            return localSolicitacoes.filter { it.status == true }.size
        }

        try {
            val list = apiService?.getSolicitacoesAbertas()
            if (list != null) {
                localSolicitacoes.clear()
                localSolicitacoes.addAll(list)
                return list.size
            }
        } catch (e: Exception) {
            Log.w("DataRepository", "getSolicitacoesAbertas failed: ${e.message}")
        }

        try {
            val list = apiService?.getSolicitacoes()
            if (list != null) {
                val abertas = list.filter { it.status == true }
                localSolicitacoes.clear()
                localSolicitacoes.addAll(list)
                return abertas.size
            }
        } catch (e: Exception) {
            Log.e("DataRepository", "getSolicitacoes failed: ${e.message}")
        }

        return localSolicitacoes.filter { it.status == true }.size
    }

    suspend fun getSolicitacoes(): List<com.example.data.model.SolicitacaoResponseDTO> {
        if (_isDemoMode.value) {
            if (localSolicitacoes.isEmpty()) {
                generateMockSolicitacoes()
            }
            return localSolicitacoes
        }

        try {
            val list = apiService?.getSolicitacoes() ?: apiService?.getSolicitacoesAbertas()
            if (list != null) {
                localSolicitacoes.clear()
                localSolicitacoes.addAll(list)
                return list
            }
        } catch (e: Exception) {
            Log.e("DataRepository", "Failed to fetch solicitacoes: ${e.message}")
        }
        return localSolicitacoes
    }

    suspend fun createSolicitacao(dto: com.example.data.model.SolicitacaoDTO): String? {
        if (_isDemoMode.value) {
            val clientName = mockClientes.find { it.codCliente == dto.cliente }?.nomCliente ?: "Cliente #${dto.cliente}"
            val newResp = com.example.data.model.SolicitacaoResponseDTO(
                id = (localSolicitacoes.size + 1).toLong(),
                idProblema = Random.nextLong(1000, 9999),
                clienteId = dto.cliente,
                cliente = clientName,
                status = true,
                problemas = dto.problemas
            )
            localSolicitacoes.add(0, newResp)
            return null
        }

        try {
            apiService?.createSolicitacao(dto)
            return null
        } catch (e: retrofit2.HttpException) {
            val errorBody = e.response()?.errorBody()?.string() ?: ""
            Log.e("DataRepository", "createSolicitacao HTTP error ${e.code()}: $errorBody")
            return "HTTP ${e.code()}: ${if (errorBody.length > 50) errorBody.take(50) + "..." else errorBody}"
        } catch (e: Exception) {
            Log.e("DataRepository", "createSolicitacao failed: ${e.message}")
            return e.message ?: "Erro desconhecido"
        }
    }

    /**
     * Troca a senha do usuário mediante confirmação da senha atual.
     * Retorna Pair(sucesso, mensagem) — a mensagem vem do backend, pra mostrar
     * tanto em caso de sucesso quanto de erro.
     */
    suspend fun trocarSenha(username: String, senhaAtual: String, senhaNova: String): Pair<Boolean, String> {
        if (_isDemoMode.value) {
            return true to "Senha alterada com sucesso. (modo demo)"
        }

        return try {
            val body = com.example.data.model.TrocarSenhaRequestDTO(username, senhaAtual, senhaNova)
            val response = apiService?.trocarSenha(body)

            if (response != null && response.isSuccessful) {
                true to (response.body()?.message ?: "Senha alterada com sucesso.")
            } else {
                val errorBody = response?.errorBody()?.string()
                val msg = try {
                    errorBody?.let {
                        Moshi.Builder()
                            .addLast(KotlinJsonAdapterFactory())
                            .build()
                            .adapter(com.example.data.model.TrocarSenhaResponseDTO::class.java)
                            .fromJson(it)?.message
                    } ?: "Não foi possível trocar a senha."
                } catch (e: Exception) {
                    "Não foi possível trocar a senha."
                }
                false to msg
            }
        } catch (e: Exception) {
            Log.e("DataRepository", "trocarSenha failed: ${e.message}")
            false to (e.message ?: "Erro inesperado ao trocar a senha.")
        }
    }

    suspend fun createCliente(cliente: com.example.data.model.Cliente): String? {
        if (_isDemoMode.value) {
            val newCliente = cliente.copy(
                codCliente = (mockClientes.maxOfOrNull { it.codCliente ?: 0L } ?: 0L) + 1,
                ativo = true
            )
            mockClientes.add(0, newCliente)
            return null
        }

        try {
            val response = apiService?.createCliente(cliente)
            if (response != null && !response.isSuccessful) {
                val errorBody = response.errorBody()?.string() ?: ""
                Log.e("DataRepository", "createCliente HTTP error ${response.code()}: $errorBody")
                return "HTTP ${response.code()}: ${if (errorBody.length > 80) errorBody.take(80) + "..." else errorBody}"
            }
            return null
        } catch (e: retrofit2.HttpException) {
            val errorBody = e.response()?.errorBody()?.string() ?: ""
            Log.e("DataRepository", "createCliente HTTP error ${e.code()}: $errorBody")
            return "HTTP ${e.code()}: ${if (errorBody.length > 80) errorBody.take(80) + "..." else errorBody}"
        } catch (e: Exception) {
            Log.e("DataRepository", "createCliente failed: ${e.message}")
            return e.message ?: "Erro desconhecido"
        }
    }

    suspend fun createMaquina(maquina: com.example.data.model.Maquina): String? {
        if (_isDemoMode.value) {
            val newMaquina = maquina.copy(
                id = Random.nextLong(1000, 9999),
                ativo = true
            )
            val clienteIdx = mockClientes.indexOfFirst { it.codCliente?.toInt() == maquina.codCliente }
            if (clienteIdx >= 0) {
                val cliente = mockClientes[clienteIdx]
                val updatedMaquinas = (cliente.maquinas ?: emptyList()) + newMaquina
                mockClientes[clienteIdx] = cliente.copy(maquinas = updatedMaquinas)
            }
            return null
        }

        try {
            val response = apiService?.createMaquina(maquina)
            if (response != null && !response.isSuccessful) {
                val errorBody = response.errorBody()?.string() ?: ""
                Log.e("DataRepository", "createMaquina HTTP error ${response.code()}: $errorBody")
                return "HTTP ${response.code()}: ${if (errorBody.length > 80) errorBody.take(80) + "..." else errorBody}"
            }
            return null
        } catch (e: retrofit2.HttpException) {
            val errorBody = e.response()?.errorBody()?.string() ?: ""
            Log.e("DataRepository", "createMaquina HTTP error ${e.code()}: $errorBody")
            return "HTTP ${e.code()}: ${if (errorBody.length > 80) errorBody.take(80) + "..." else errorBody}"
        } catch (e: Exception) {
            Log.e("DataRepository", "createMaquina failed: ${e.message}")
            return e.message ?: "Erro desconhecido"
        }
    }

    suspend fun updateCliente(id: Long, cliente: com.example.data.model.Cliente): String? {
        if (_isDemoMode.value) {
            val idx = mockClientes.indexOfFirst { it.codCliente == id }
            if (idx >= 0) {
                mockClientes[idx] = cliente.copy(codCliente = id, ativo = mockClientes[idx].ativo)
            }
            return null
        }

        try {
            val response = apiService?.updateCliente(id, cliente)
            if (response != null && !response.isSuccessful) {
                val errorBody = response.errorBody()?.string() ?: ""
                Log.e("DataRepository", "updateCliente HTTP error ${response.code()}: $errorBody")
                return "HTTP ${response.code()}: ${if (errorBody.length > 80) errorBody.take(80) + "..." else errorBody}"
            }
            return null
        } catch (e: retrofit2.HttpException) {
            val errorBody = e.response()?.errorBody()?.string() ?: ""
            Log.e("DataRepository", "updateCliente HTTP error ${e.code()}: $errorBody")
            return "HTTP ${e.code()}: ${if (errorBody.length > 80) errorBody.take(80) + "..." else errorBody}"
        } catch (e: Exception) {
            Log.e("DataRepository", "updateCliente failed: ${e.message}")
            return e.message ?: "Erro desconhecido"
        }
    }

    suspend fun desativarCliente(id: Long): String? {
        if (_isDemoMode.value) {
            val idx = mockClientes.indexOfFirst { it.codCliente == id }
            if (idx >= 0) {
                mockClientes[idx] = mockClientes[idx].copy(ativo = false)
            }
            return null
        }

        try {
            val response = apiService?.desativarCliente(id)
            if (response != null && !response.isSuccessful) {
                val errorBody = response.errorBody()?.string() ?: ""
                Log.e("DataRepository", "desativarCliente HTTP error ${response.code()}: $errorBody")
                return "HTTP ${response.code()}: ${if (errorBody.length > 80) errorBody.take(80) + "..." else errorBody}"
            }
            return null
        } catch (e: retrofit2.HttpException) {
            val errorBody = e.response()?.errorBody()?.string() ?: ""
            Log.e("DataRepository", "desativarCliente HTTP error ${e.code()}: $errorBody")
            return "HTTP ${e.code()}: ${if (errorBody.length > 80) errorBody.take(80) + "..." else errorBody}"
        } catch (e: Exception) {
            Log.e("DataRepository", "desativarCliente failed: ${e.message}")
            return e.message ?: "Erro desconhecido"
        }
    }

    suspend fun updateMaquina(id: Int, maquina: com.example.data.model.Maquina): String? {
        if (_isDemoMode.value) {
            return null
        }

        try {
            val response = apiService?.updateMaquina(id, maquina)
            if (response != null && !response.isSuccessful) {
                val errorBody = response.errorBody()?.string() ?: ""
                Log.e("DataRepository", "updateMaquina HTTP error ${response.code()}: $errorBody")
                return "HTTP ${response.code()}: ${if (errorBody.length > 80) errorBody.take(80) + "..." else errorBody}"
            }
            return null
        } catch (e: retrofit2.HttpException) {
            val errorBody = e.response()?.errorBody()?.string() ?: ""
            Log.e("DataRepository", "updateMaquina HTTP error ${e.code()}: $errorBody")
            return "HTTP ${e.code()}: ${if (errorBody.length > 80) errorBody.take(80) + "..." else errorBody}"
        } catch (e: Exception) {
            Log.e("DataRepository", "updateMaquina failed: ${e.message}")
            return e.message ?: "Erro desconhecido"
        }
    }

    suspend fun desativarMaquina(id: Int): String? {
        if (_isDemoMode.value) {
            return null
        }

        try {
            val response = apiService?.desativarMaquina(id)
            if (response != null && !response.isSuccessful) {
                val errorBody = response.errorBody()?.string() ?: ""
                Log.e("DataRepository", "desativarMaquina HTTP error ${response.code()}: $errorBody")
                return "HTTP ${response.code()}: ${if (errorBody.length > 80) errorBody.take(80) + "..." else errorBody}"
            }
            return null
        } catch (e: retrofit2.HttpException) {
            val errorBody = e.response()?.errorBody()?.string() ?: ""
            Log.e("DataRepository", "desativarMaquina HTTP error ${e.code()}: $errorBody")
            return "HTTP ${e.code()}: ${if (errorBody.length > 80) errorBody.take(80) + "..." else errorBody}"
        } catch (e: Exception) {
            Log.e("DataRepository", "desativarMaquina failed: ${e.message}")
            return e.message ?: "Erro desconhecido"
        }
    }

    suspend fun getExecucoes(): List<com.example.data.model.ExecucaoDTO> {        if (_isDemoMode.value) {
            return listOf(
                com.example.data.model.ExecucaoDTO(
                    id = 1L, nomeCliente = "Demo Cliente", nomeMaquina = "Demo Máquina",
                    descricaoProblema = "Tela piscando", descricao = "Troca de placa realizada",
                    tecnico = "Técnico Demo", pdfGerado = false
                )
            )
        }

        return try {
            apiService?.getExecucoes() ?: emptyList()
        } catch (e: Exception) {
            Log.e("DataRepository", "getExecucoes failed: ${e.message}")
            emptyList()
        }
    }

    suspend fun registrarExecucao(
        lista: List<com.example.data.model.ExecucaoRequestDTO>
    ): String? {
        if (_isDemoMode.value) {
            // Demo: marca a solicitação como concluída localmente
            lista.firstOrNull()?.solicitacaoId?.let { sid ->
                val idx = localSolicitacoes.indexOfFirst { it.id == sid }
                if (idx >= 0) {
                    localSolicitacoes[idx] = localSolicitacoes[idx].copy(status = false)
                }
            }
            return null
        }

        return try {
            val response = apiService?.registrarExecucao(lista)
            if (response != null && !response.isSuccessful) {
                val body = response.errorBody()?.string() ?: ""
                Log.e("DataRepository", "registrarExecucao HTTP ${response.code()}: $body")
                "HTTP ${response.code()}: ${body.take(80)}"
            } else {
                null
            }
        } catch (e: retrofit2.HttpException) {
            val body = e.response()?.errorBody()?.string() ?: ""
            Log.e("DataRepository", "registrarExecucao HTTP ${e.code()}: $body")
            "HTTP ${e.code()}: ${body.take(80)}"
        } catch (e: Exception) {
            Log.e("DataRepository", "registrarExecucao failed: ${e.message}")
            e.message ?: "Erro desconhecido"
        }
    }

    suspend fun getCategorias(): List<com.example.data.model.CategoriaDTO> {
        if (_isDemoMode.value) {
            return listOf(
                com.example.data.model.CategoriaDTO(1L, "Placa Mãe", "pl"),
                com.example.data.model.CategoriaDTO(2L, "Fonte", "fo"),
                com.example.data.model.CategoriaDTO(3L, "Monitor", "mo")
            )
        }
        return try {
            apiService?.getCategorias() ?: emptyList()
        } catch (e: Exception) {
            Log.e("DataRepository", "getCategorias failed: ${e.message}")
            emptyList()
        }
    }

    suspend fun getSubCategorias(categoriaId: Long?): List<com.example.data.model.SubCategoriaDTO> {
        if (_isDemoMode.value) {
            if (categoriaId != 3L) return emptyList()
            return listOf(
                com.example.data.model.SubCategoriaDTO(1L, "15 Pol."),
                com.example.data.model.SubCategoriaDTO(2L, "17 Pol."),
                com.example.data.model.SubCategoriaDTO(3L, "18 Pol."),
                com.example.data.model.SubCategoriaDTO(4L, "19 Pol."),
                com.example.data.model.SubCategoriaDTO(5L, "Outros")
            )
        }
        return try {
            apiService?.getSubCategorias(categoriaId) ?: emptyList()
        } catch (e: Exception) {
            Log.e("DataRepository", "getSubCategorias failed: ${e.message}")
            emptyList()
        }
    }

    suspend fun criarSubCategoria(nome: String, categoriaId: Long): com.example.data.model.SubCategoriaDTO? {
        return try {
            val request = com.example.data.model.CriarSubCategoriaRequest(
                nome = nome,
                categoria = com.example.data.model.CategoriaRefDTO(id = categoriaId)
            )
            val response = apiService?.criarSubCategoria(request)
            if (response?.isSuccessful == true) response.body() else null
        } catch (e: Exception) {
            Log.e("DataRepository", "criarSubCategoria failed: ${e.message}")
            null
        }
    }

    suspend fun getPecasDisponiveis(categoriaId: Long): List<com.example.data.model.PecaDTO> {
        if (_isDemoMode.value) {
            // Demo com subcategorias (Monitor) pra conferir o agrupamento na tela de execução
            if (categoriaId == 3L) {
                val subs = listOf(
                    Pair(1L, "15 Pol."),
                    Pair(2L, "17 Pol."),
                    Pair(3L, "18 Pol."),
                    Pair(4L, "19 Pol.")
                )
                val demoMonitores = mutableListOf<com.example.data.model.PecaDTO>()
                var seq = 0
                subs.forEach { sub ->
                    repeat(2) {
                        seq += 1
                        demoMonitores.add(
                            com.example.data.model.PecaDTO(
                                idPeca = 300L + seq,
                                codigo = "MO-000$seq",
                                status = "ESTOQUE",
                                categoriaId = categoriaId,
                                categoriaNome = "Monitor",
                                categoriaAlias = "mo",
                                subCategoriaId = sub.first,
                                subCategoriaNome = sub.second
                            )
                        )
                    }
                }
                return demoMonitores
            }
            return listOf(
                com.example.data.model.PecaDTO(
                    idPeca = 101L,
                    codigo = "PL-0041",
                    status = "ESTOQUE",
                    categoriaId = categoriaId,
                    categoriaNome = "Placa Mãe",
                    categoriaAlias = "pl"
                ),
                com.example.data.model.PecaDTO(
                    idPeca = 102L,
                    codigo = "PL-0042",
                    status = "ESTOQUE",
                    categoriaId = categoriaId,
                    categoriaNome = "Placa Mãe",
                    categoriaAlias = "pl"
                ),
                com.example.data.model.PecaDTO(
                    idPeca = 103L,
                    codigo = "PL-0043",
                    status = "ESTOQUE",
                    categoriaId = categoriaId,
                    categoriaNome = "Placa Mãe",
                    categoriaAlias = "pl"
                )
            )
        }
        return try {
            apiService?.getPecasDisponiveis(categoriaId) ?: emptyList()
        } catch (e: Exception) {
            Log.e("DataRepository", "getPecasDisponiveis failed: ${e.message}")
            emptyList()
        }
    }


    suspend fun getLotes(): List<com.example.data.model.LoteDTO> {
        if (_isDemoMode.value) {
            return listOf(
                com.example.data.model.LoteDTO(1L, "PL", "Fornecedor Demo", "L001", "Lote demo placas", 10, 7, "2026-06-01",
                    com.example.data.model.CategoriaDTO(1L, "Placa Mae", "pl")),
                com.example.data.model.LoteDTO(2L, "FO", "Fornecedor Demo", "L002", "Lote demo fontes", 5, 5, "2026-06-10",
                    com.example.data.model.CategoriaDTO(2L, "Fonte", "fo"))
            )
        }
        return try {
            apiService?.getLotes() ?: emptyList()
        } catch (e: Exception) {
            Log.e("DataRepository", "getLotes failed: ${e.message}")
            emptyList()
        }
    }

    suspend fun getPecasDoLote(loteId: Long): List<com.example.data.model.PecaDTO> {
        return try {
            apiService?.getPecasDoLote(loteId) ?: emptyList()
        } catch (e: Exception) {
            Log.e("DataRepository", "getPecasDoLote failed: ${e.message}")
            emptyList()
        }
    }

    suspend fun getFaixaPecasDoLote(loteId: Long): Pair<String?, String?> {
        return try {
            val resultado = apiService?.getFaixaPecasDoLote(loteId)
            Pair(resultado?.get("primeiro"), resultado?.get("ultimo"))
        } catch (e: Exception) {
            Log.e("DataRepository", "getFaixaPecasDoLote failed: ${e.message}")
            Pair(null, null)
        }
    }

    suspend fun getJogos(): List<com.example.data.model.JogoDTO> {
        return try {
            apiService?.getJogos() ?: emptyList()
        } catch (e: Exception) {
            Log.e("DataRepository", "getJogos failed: ${e.message}")
            emptyList()
        }
    }

    suspend fun criarLoteManual(request: com.example.data.model.LoteManualRequestDTO): com.example.data.model.LoteDTO? {
        return try {
            val response = apiService?.criarLoteManual(request)
            if (response?.isSuccessful == true) response.body() else null
        } catch (e: Exception) {
            Log.e("DataRepository", "criarLoteManual failed: ${e.message}")
            null
        }
    }

    suspend fun retirarPeca(idPeca: Long, observacao: String?, usuarioResponsavel: String?): Boolean {
        return try {
            val request = com.example.data.model.PecaAcaoRequestDTO(observacao, usuarioResponsavel)
            val response = apiService?.retirarPeca(idPeca, request)
            response?.isSuccessful == true
        } catch (e: Exception) {
            Log.e("DataRepository", "retirarPeca failed: ${e.message}")
            false
        }
    }

    suspend fun descartarPeca(idPeca: Long, observacao: String?, usuarioResponsavel: String?): Boolean {
        return try {
            val request = com.example.data.model.PecaAcaoRequestDTO(observacao, usuarioResponsavel)
            val response = apiService?.descartarPeca(idPeca, request)
            response?.isSuccessful == true
        } catch (e: Exception) {
            Log.e("DataRepository", "descartarPeca failed: ${e.message}")
            false
        }
    }

    suspend fun criarLote(request: com.example.data.model.LoteRequestDTO): com.example.data.model.LoteDTO? {
        return try {
            val response = apiService?.criarLote(request)
            if (response?.isSuccessful == true) response.body() else null
        } catch (e: Exception) {
            Log.e("DataRepository", "criarLote failed: ${e.message}")
            null
        }
    }

    suspend fun criarCategoria(nome: String, alias: String): com.example.data.model.CategoriaDTO? {
        return try {
            val request = com.example.data.model.CriarCategoriaRequest(nome = nome, alias = alias)
            val response = apiService?.criarCategoria(request)
            if (response?.isSuccessful == true) response.body() else null
        } catch (e: Exception) {
            Log.e("DataRepository", "criarCategoria failed: ${e.message}")
            null
        }
    }


    suspend fun salvarLogEnvio(request: com.example.data.model.LogEnvioRequestDTO): Boolean {
        return try {
            val response = apiService?.salvarLogEnvio(request)
            response?.isSuccessful == true
        } catch (e: Exception) {
            Log.e("DataRepository", "salvarLogEnvio failed: ${e.message}")
            false
        }
    }

    suspend fun listarLogEnvios(): List<com.example.data.model.LogEnvioDTO> {
        return try {
            apiService?.listarLogEnvios() ?: emptyList()
        } catch (e: Exception) {
            Log.e("DataRepository", "listarLogEnvios failed: ${e.message}")
            emptyList()
        }
    }

    private fun generateMockSolicitacoes() {
        localSolicitacoes.clear()
        for (i in 1..8) {
            val cli = mockClientes.getOrNull(Random.nextInt(mockClientes.size.coerceAtLeast(1)))
            val problems = listOf(
                com.example.data.model.ProblemaDTO(
                    idProblema = i.toLong() * 10,
                    maquina = "Slot Model " + ('A' + Random.nextInt(5)),
                    descricao = "Tela piscando ou máquina travada"
                )
            )
            localSolicitacoes.add(
                com.example.data.model.SolicitacaoResponseDTO(
                    id = i.toLong(),
                    idProblema = i.toLong() * 10,
                    clienteId = cli?.codCliente,
                    cliente = cli?.nomCliente ?: "Bar do Ponto $i",
                    status = true,
                    problemas = problems
                )
            )
        }
    }
}

class SimpleCookieJar : okhttp3.CookieJar {
    private val cookieStore = HashMap<String, List<okhttp3.Cookie>>()

    override fun saveFromResponse(url: okhttp3.HttpUrl, cookies: List<okhttp3.Cookie>) {
        cookieStore[url.host] = cookies
    }

    override fun loadForRequest(url: okhttp3.HttpUrl): List<okhttp3.Cookie> {
        return cookieStore[url.host] ?: emptyList()
    }
}
