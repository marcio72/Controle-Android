package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Colors (Vibrant Orange & Dark Navy)
val BrandOrange = Color(0xFFFF6D00)      // Sleek energetic Orange accent
val SecondaryOrange = Color(0xFFFF851B)  // Lighter secondary orange
val DeepDarkNavy = Color(0xFF050A14)     // Pure dark background canvas
val SleekNavyCard = Color(0xFF0D1B2D)    // Premium dark blue card shape
val NavySurface = Color(0xFF11223F)      // Lighter accent surface navy
val AccentGold = Color(0xFFFFB703)       // Warm Amber/Gold highlight

// Compatibility Aliases to keep existing code compiling perfectly
val PrimaryBlue = Color(0xFFFF6D00)      // Map to BrandOrange!
val SecondaryEmerald = Color(0xFF38BDF8) // High-tech light blue / cyan for active items
val AccentAmber = Color(0xFFFFB703)      // Warm golden accent

// Light Color Scheme Shades
val LightBackground = Color(0xFFF8FAFC)  // Clean grayish slate
val LightSurface = Color(0xFFFFFFFF)     // True White
val LightTextPrimary = Color(0xFF0F172A) // Slate 900
val LightTextSecondary = Color(0xFF475569) // Slate 600

// Dark Color Scheme Shades
val DarkBackground = DeepDarkNavy
val DarkSurface = SleekNavyCard
val DarkPrimary = BrandOrange
val DarkSecondary = SecondaryOrange
val DarkTextPrimary = Color(0xFFFFFFFF)  // White
val DarkTextSecondary = Color(0xFF94A3B8) // Slate 400
